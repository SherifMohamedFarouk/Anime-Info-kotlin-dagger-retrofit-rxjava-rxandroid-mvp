package com.example.ainfo.utils

var base_url = "https://api.jikan.moe/v3"