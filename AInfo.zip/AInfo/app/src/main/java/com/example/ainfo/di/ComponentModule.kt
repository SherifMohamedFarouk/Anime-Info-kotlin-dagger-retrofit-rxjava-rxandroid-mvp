package com.veirn.animest.di


import dagger.Module
import dagger.Provides

@Module
class ComponentModule {


//@Provides
////fun providerepostairy(): MainRepostairy {
////    return MainRepostairy();
////
////}

}